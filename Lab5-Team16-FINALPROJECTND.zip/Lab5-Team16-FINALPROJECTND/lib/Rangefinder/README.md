# Rangefinder
Library for various rangefinders. See individual `.h` and `.cpp` files for comments.

## Datasheets
* [HC-SR04 rangefinder](https://media.digikey.com/pdf/Data%20Sheets/Adafruit%20PDFs/3942_Web.pdf).
* [MaxBotix](https://www.maxbotix.com/documents/LV-MaxSonar-EZ_Datasheet.pdf)
* [Sharp IR Proximity Detector](https://www.pololu.com/file/0J85/gp2y0a21yk0f.pdf)