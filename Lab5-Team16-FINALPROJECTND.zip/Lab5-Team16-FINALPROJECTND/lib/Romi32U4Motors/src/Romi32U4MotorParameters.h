#define KP_MOTOR    5.0
#define KI_MOTOR    0.5
#define KD_MOTOR    0.0             // don't use

#define INTEGRAL_CAP_MOTOR  0.0     // if you want to add an integral cap